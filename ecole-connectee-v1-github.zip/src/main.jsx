import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const initialStudent = {
  name: "Moussa Gomis",
  className: "6ème A",
  school: "École Exemple Dakar",
  status: "absent",
  arrival: null,
  departure: null,
};

function App() {
  const [page, setPage] = useState("home");
  const [student, setStudent] = useState(initialStudent);
  const [notifications, setNotifications] = useState([]);

  const now = () =>
    new Date().toLocaleTimeString("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
    });

  function simulateArrival() {
    const time = now();
    setStudent(s => ({ ...s, status: "present", arrival: time, departure: null }));
    setNotifications(n => [
      {
        id: Date.now(),
        title: "Arrivée confirmée",
        text: `${student.name} est bien arrivé à l'école à ${time}.`,
        type: "success",
      },
      ...n,
    ]);
    setPage("parent");
  }

  function simulateDeparture() {
    const time = now();
    setStudent(s => ({ ...s, status: "departed", departure: time }));
    setNotifications(n => [
      {
        id: Date.now(),
        title: "Départ de l'école",
        text: `${student.name} vient de quitter l'établissement à ${time}.`,
        type: "info",
      },
      ...n,
    ]);
    setPage("parent");
  }

  function resetDemo() {
    setStudent(initialStudent);
    setNotifications([]);
    setPage("home");
  }

  return (
    <div className="app">
      <header className="topbar">
        <button className="brand" onClick={() => setPage("home")}>
          <span className="brandMark">EC</span>
          <span>
            <strong>École Connectée</strong>
            <small>Connecter l’école, rassurer les parents</small>
          </span>
        </button>
        <nav>
          <button className={page === "parent" ? "active" : ""} onClick={() => setPage("parent")}>Parent</button>
          <button className={page === "school" ? "active" : ""} onClick={() => setPage("school")}>École</button>
          <button className="demoBtn" onClick={() => setPage("demo")}>Démo</button>
        </nav>
      </header>

      <main>
        {page === "home" && (
          <section className="hero">
            <div className="heroText">
              <span className="eyebrow">PROTOTYPE V1 • DÉMO INTERACTIVE</span>
              <h1>La sécurité et le suivi des élèves, <span>au cœur de l’école.</span></h1>
              <p>
                École Connectée permet aux établissements de suivre les entrées et
                sorties des élèves et d'informer les parents en temps réel.
              </p>
              <div className="actions">
                <button className="primary" onClick={() => setPage("parent")}>Ouvrir l’espace parent</button>
                <button className="secondary" onClick={() => setPage("school")}>Voir l’espace école</button>
              </div>
              <div className="miniStats">
                <div><b>856</b><span>Élèves</span></div>
                <div><b>791</b><span>Présents</span></div>
                <div><b>100%</b><span>Suivi</span></div>
              </div>
            </div>
            <div className="phone">
              <div className="phoneHeader">Bonjour, Parent 👋</div>
              <div className="phoneCard">
                <div className="avatar">MG</div>
                <div><b>{student.name}</b><small>{student.className}</small></div>
                <Status status={student.status}/>
              </div>
              <div className="phoneNotice">
                <span>🔔</span>
                <div><b>Notifications</b><small>{notifications.length ? notifications[0].text : "Aucune nouvelle notification"}</small></div>
              </div>
              <div className="phoneLine"><span>Arrivée</span><b>{student.arrival || "—"}</b></div>
              <div className="phoneLine"><span>Départ</span><b>{student.departure || "—"}</b></div>
            </div>
          </section>
        )}

        {page === "parent" && (
          <section className="dashboard">
            <div className="sectionHead">
              <div><span className="eyebrow">ESPACE PARENT</span><h2>Tableau de bord</h2></div>
              <button className="secondary" onClick={() => setPage("notifications")}>🔔 Notifications ({notifications.length})</button>
            </div>
            <div className="studentMain card">
              <div className="studentIdentity">
                <div className="bigAvatar">MG</div>
                <div><h3>{student.name}</h3><p>{student.className} · {student.school}</p></div>
              </div>
              <Status status={student.status}/>
            </div>
            <div className="grid3">
              <InfoCard title="Arrivée" value={student.arrival || "—"} icon="↘"/>
              <InfoCard title="Présence" value={student.status === "present" ? "Présent" : student.status === "departed" ? "Sorti" : "En attente"} icon="✓"/>
              <InfoCard title="Départ" value={student.departure || "—"} icon="↗"/>
            </div>
            <div className="card">
              <div className="cardTitle"><h3>Historique récent</h3><span>Cette semaine</span></div>
              <div className="history">
                {["Lundi","Mardi","Mercredi","Jeudi","Vendredi"].map((d,i)=>(
                  <div className="historyRow" key={d}><b>{d}</b><span>Présent</span><small>{i===4 ? (student.arrival || "07:48") : "07:50"}</small></div>
                ))}
              </div>
            </div>
          </section>
        )}

        {page === "notifications" && (
          <section className="dashboard narrow">
            <div className="sectionHead"><div><span className="eyebrow">ESPACE PARENT</span><h2>Notifications</h2></div><button className="secondary" onClick={() => setPage("parent")}>← Retour</button></div>
            {notifications.length === 0 ? (
              <div className="empty card"><span>🔔</span><h3>Aucune notification</h3><p>Utilisez la démo pour simuler l’arrivée ou le départ de l’élève.</p></div>
            ) : notifications.map(n=>(
              <div className={`notification card ${n.type}`} key={n.id}><div className="notifIcon">🔔</div><div><b>{n.title}</b><p>{n.text}</p></div></div>
            ))}
          </section>
        )}

        {page === "school" && (
          <section className="dashboard">
            <div className="sectionHead"><div><span className="eyebrow">ESPACE ÉCOLE</span><h2>Administration</h2></div><button className="demoBtn" onClick={() => setPage("demo")}>Lancer une simulation</button></div>
            <div className="grid4">
              <Metric label="Élèves" value="856"/>
              <Metric label="Présents" value={student.status === "present" ? "792" : "791"}/>
              <Metric label="Absents" value={student.status === "absent" ? "43" : "42"}/>
              <Metric label="Retards" value="23"/>
            </div>
            <div className="card">
              <div className="cardTitle"><h3>Suivi des élèves</h3><span>Actualisation en direct</span></div>
              <div className="tableWrap">
                <table><thead><tr><th>Élève</th><th>Classe</th><th>Arrivée</th><th>Départ</th><th>Statut</th></tr></thead>
                <tbody>
                  <tr><td><b>{student.name}</b></td><td>{student.className}</td><td>{student.arrival || "—"}</td><td>{student.departure || "—"}</td><td><Status status={student.status}/></td></tr>
                  <tr><td>Fatou Ndiaye</td><td>6ème A</td><td>07:52</td><td>—</td><td><Status status="present"/></td></tr>
                  <tr><td>Ibrahima Fall</td><td>6ème B</td><td>—</td><td>—</td><td><Status status="absent"/></td></tr>
                </tbody></table>
              </div>
            </div>
          </section>
        )}

        {page === "demo" && (
          <section className="dashboard narrow">
            <div className="sectionHead"><div><span className="eyebrow">DÉMONSTRATION</span><h2>Simulation arrivée / départ</h2></div><button className="secondary" onClick={resetDemo}>Réinitialiser</button></div>
            <div className="scenario card">
              <div className="scenarioStudent"><div className="bigAvatar">MG</div><div><h3>{student.name}</h3><p>{student.className} · {student.school}</p></div></div>
              <Status status={student.status}/>
              <div className="timeline">
                <Step done={!!student.arrival} title="Arrivée à l’école" value={student.arrival || "En attente"}/>
                <Step done={!!student.departure} title="Départ de l’école" value={student.departure || "En attente"}/>
                <Step done={notifications.length > 0} title="Notification parent" value={notifications.length ? "Envoyée" : "En attente"}/>
              </div>
              <div className="actions">
                <button className="primary" disabled={student.status === "present" || student.status === "departed"} onClick={simulateArrival}>✓ Simuler l’arrivée</button>
                <button className="secondary" disabled={student.status !== "present"} onClick={simulateDeparture}>↗ Simuler le départ</button>
              </div>
            </div>
            <div className="explain"><b>Scénario investisseur :</b> l’école enregistre l’entrée de Moussa → son statut devient « Présent » → le parent reçoit une notification → à la sortie, une nouvelle notification est envoyée.</div>
          </section>
        )}
      </main>

      <footer>© 2026 École Connectée · Prototype de démonstration · Dakar, Sénégal</footer>
    </div>
  );
}

function Status({status}) {
  const map = {present:["present","Présent"], absent:["absent","Absent"], departed:["departed","Sorti"]};
  const [cls,label] = map[status] || map.absent;
  return <span className={`status ${cls}`}><i/> {label}</span>;
}
function InfoCard({title,value,icon}) { return <div className="metric card"><span className="metricIcon">{icon}</span><small>{title}</small><strong>{value}</strong></div>; }
function Metric({label,value}) { return <div className="metric card"><small>{label}</small><strong>{value}</strong><span>Aujourd’hui</span></div>; }
function Step({done,title,value}) { return <div className="step"><span className={done ? "stepDot done":"stepDot"}>{done ? "✓":""}</span><div><b>{title}</b><small>{value}</small></div></div>; }

createRoot(document.getElementById("root")).render(<App />);
