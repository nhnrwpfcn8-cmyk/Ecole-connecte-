# École Connectée — Prototype V1

Démo interactive de l'application École Connectée.

## Fonctionnalités

- Page d'accueil
- Espace Parent
- Espace École
- Notifications simulées
- Historique de présence
- Simulation d'arrivée d'un élève
- Simulation de départ d'un élève
- Mise à jour des statuts en direct
- Interface responsive mobile/ordinateur

## Installation

Installer Node.js (version LTS), puis dans le dossier du projet :

```bash
npm install
npm run dev
```

Ouvrir l'adresse indiquée par Vite dans le navigateur.

## Build production

```bash
npm run build
npm run preview
```

## Déploiement GitHub / Vercel

1. Créer un dépôt GitHub nommé `ecole-connectee`.
2. Ajouter tous les fichiers de ce dossier.
3. Connecter le dépôt à Vercel.
4. Vercel détectera automatiquement Vite et construira le projet avec `npm run build`.

> Cette V1 utilise des données fictives et des simulations locales. La base de données, les comptes utilisateurs et les vraies notifications seront ajoutés dans une prochaine version.
